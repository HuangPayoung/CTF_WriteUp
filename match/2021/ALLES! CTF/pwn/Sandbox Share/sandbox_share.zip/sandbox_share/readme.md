# readme

## General

Steps to replicate the remote setup:

1. First run `install.sh` to build and install all required files.  
2. Afterwards, run `run.sh`.  

If you need to restart the `sandbox_share_xpc` service, run `restart_service.sh`.

## Notes

- Your exploit should take the service name from `argv[1]`
